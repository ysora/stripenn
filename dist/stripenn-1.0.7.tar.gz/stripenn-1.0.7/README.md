Architectural stripe detection tool
