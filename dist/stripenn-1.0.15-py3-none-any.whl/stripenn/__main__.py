from .stripenn import main
main()
