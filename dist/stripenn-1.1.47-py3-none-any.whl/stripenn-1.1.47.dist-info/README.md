
**Stripenn** is a command line interface python package developed for detection of atchitectural stripes from 3D genome conformation data. For installation and usage, please refer to the github page (https://github.com/ysora/stripenn)
